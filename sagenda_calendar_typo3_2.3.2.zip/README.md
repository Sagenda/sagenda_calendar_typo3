# sagenda-calendar-typo3
Sagenda's Calendar Typo3 (v9.x) and (v10.x) extension.

We don't recommend using Typo3 version 8.x anymore as this version was officially declared END OF LIFE in March 31st, 2020 : https://typo3.org/article/typo3-core-9-5-15-and-8-7-32-maintenance-releases-published 
Please update to at least version 9.x.

Please use at least PHP 7.2 (PHP 7.4 or 8 recommended).