<?php
namespace Sagenda\SagendaCalendarTypo3\Domain\Model;

/***
 *
 * This file is part of the "Sagenda Calendar Typo3" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2019 Sagenda
 *
 ***/

/**
 * Sagendacalendartypo3
 */
class Sagendacalendartypo3 extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    }
