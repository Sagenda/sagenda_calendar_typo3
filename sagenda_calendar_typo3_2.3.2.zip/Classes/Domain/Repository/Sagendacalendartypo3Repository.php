<?php
namespace Sagenda\SagendaCalendarTypo3\Domain\Repository;

/***
 *
 * This file is part of the "Sagenda Calendar Typo3" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2019 Sagenda
 *
 ***/

/**
 * The repository for Sagendacalendartypo3s
 */
class Sagendacalendartypo3Repository extends \TYPO3\CMS\Extbase\Persistence\Repository
{
    }
